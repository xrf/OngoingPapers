function term = corr_term(N, rs, mu)

term = -1.5/(N*mu^2*rs^3);